package Database;
import java.sql.*;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package Database;

/**
 *
 * @author Chioma Okeke
 */
public class DatabaseHandler {
    private static final String url ="jdbc:derby:database;create=true";
    private static Connection conn = null;
    private static Statement stmt = null;
    public static DatabaseHandler data = null;

public DatabaseHandler(){
     createConnection();
     createStudent();

 
}
public static DatabaseHandler getInstance(){
        if(data == null){
            data = new DatabaseHandler();
        }
        return data;
    }




void createConnection(){
try{
       Class.forName("org.apache.derby.jdbc.EmbeddedDriver").newInstance();
       conn = DriverManager.getConnection(url);
       stmt = conn.createStatement();
            System.out.println("connection successful");
        }
    catch(Exception e){
            e.printStackTrace();
        }

}

    void createStudent(){
    try{
        
     String sql = "create table student("+
                     "regnumber varchar(11) primary key ,"+
                     "surname varchar(32) ,"+
                     "firstname varchar(32) ,"+
                     "middlename varchar(22) ,"+
                     "State varchar(22) ,"+
                     "DOB varchar(11) ,"+
                     "gender varchar(10) ,"+
                     "studentphone varchar(12) ,"+
                     "guardian1phone varchar(12) ,"+
                     "guardian2phone varchar(12) ,"+
                     "entrymode varchar(35) ,"+
                     "address varchar(50) ,"+
                     "faculty varchar(22) ,"+
                     "department varchar(32) ,"+
                     "classlevel varchar(10))";
                 stmt.executeUpdate(sql);
                  System.out.println("Table created.");
                         
       
    }
    catch(Exception e){
        System.out.println("hey"+e.getMessage());
    }

}  
    
  
public boolean executeAction(String sql){
    try{
        stmt.executeUpdate(sql);
        return true;
    }
    catch(Exception e){
       System.out.println(e.getMessage());
       return false;
          
    }
}
public ResultSet executeQuery(String sql){
    ResultSet result = null;
    try{
        result = stmt.executeQuery(sql);
    }
    catch(Exception e){
          System.out.println(e.getMessage());
    }
    return result;
}
public boolean executeActions(String rsql){
    try{
        stmt.executeUpdate(rsql);
        return true;
    }
    catch(Exception e){
       System.out.println(e.getMessage());
       return false;
          
    }
}
public ResultSet executeQueries(String rsql){
    ResultSet results = null;
    try{
        results = stmt.executeQuery(rsql);
    }
    catch(Exception e){
          System.out.println(e.getMessage());
    }
    return results;
}

   

    
}

