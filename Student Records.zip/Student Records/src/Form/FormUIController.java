/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Form;

import Database.DatabaseHandler;
import com.jfoenix.controls.JFXTextField;
import com.jfoenix.effects.JFXDepthManager;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author Chioma Okeke
 */
public class FormUIController implements Initializable {
DatabaseHandler data = null;
    @FXML
    private JFXTextField search;
    @FXML
    private Pane registerBox;
    @FXML
    private ImageView Register;
    @FXML
    private Pane recordBox;
    @FXML
    private ImageView Records;
    @FXML
    private AnchorPane FormPane;
    @FXML
    private ImageView searchicon;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        data = DatabaseHandler.getInstance();
        JFXDepthManager.setDepth(registerBox,2);
        JFXDepthManager.setDepth(recordBox,2);
    }    
  

    @FXML
    private void registerStudent(ActionEvent event) {
        try{
            Parent root= FXMLLoader.load(getClass().getResource("..\\Register\\RegisterUI.fxml"));
            Scene scene = new Scene(root);
            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setResizable(false);
            stage.setTitle("Register A Student");
            stage.setScene(scene);
            stage.show();
        }
        catch(Exception e){
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText(null);
            alert.setContentText(e.getMessage());
            alert.showAndWait();}  
            try{
            Exit();
            }
            catch(Exception e){
                System.out.println(e.getMessage());
            }
        }
    

    @FXML
    private void seeRecords(ActionEvent event) {
         try{
            Parent root= FXMLLoader.load(getClass().getResource("..\\Records\\RecordsUI.fxml"));
            Scene scene = new Scene(root);
            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setResizable(true);
            stage.setTitle("Student Records");
            stage.setScene(scene);
            stage.show();
        }
        catch(Exception e){
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText(null);
            alert.setContentText(e.getMessage());
            alert.showAndWait();}  
            try{
            Exit();
            }
            catch(Exception e){
                System.out.println(e.getMessage());
            }
    }
    
    void Exit() throws IOException {
            Stage stage = (Stage) FormPane.getScene().getWindow();
            stage.close();
    
    } 

    @FXML
    private void searchForDetails(KeyEvent event) {
         String regno = search.getText();
         String sql = "select regnumber,surname,firstname,middlename,gender,studentphone,department,classlevel from student where regnumber = '"+regno+"' ";
         ResultSet r = data.executeQuery(sql);
         String regnum = "";
         String sname = "";
         String fname = "";
         String mname = "";
         String gender = "";
         String sphone = "";
         String dept = "";
         String level = "";
         try{
             while(r.next()){
                 regnum = r.getString("regnumber");
                 sname = r.getString("surname");
                 fname = r.getString("firstname");
                 mname = r.getString("middlename");
                 gender = r.getString("gender");
                 sphone = r.getString("studentphone");
                 dept = r.getString("department");
                 level = r.getString("classlevel");
             }
         }
             catch (Exception e)
               {
                   System.out.println(e.getMessage()); 
                     }
         if(!regnum.equals("")){
        JOptionPane.showMessageDialog(null, "\t Name: " +sname+" "+fname+" "+mname+"\n Reg no: "+regnum+"\n Gender: "+gender+"\n Phone Number: "+sphone+"\n Department: "+dept+"\n Level: "+level, "INFORMATION", JOptionPane.PLAIN_MESSAGE );
         }
         else{
             Alert alert = new Alert(Alert.AlertType.INFORMATION);
             alert.setHeaderText(null);
             alert.setContentText("Student not found");
             alert.showAndWait();
         }
    }

    @FXML
    private void searchForDetails(ActionEvent event) {
         String regno = search.getText();
        String sql = "select regnumber,surname,firstname,middlename,gender,studentphone,department,classlevel from student where regnumber = '"+regno+"' ";
         ResultSet r = data.executeQuery(sql);
         String regnum = "";
         String sname = "";
         String fname = "";
         String mname = "";
         String gender = "";
         String sphone = "";
         String dept = "";
         String level = "";
         try{
             while(r.next()){
                 regnum = r.getString("regnumber");
                 sname = r.getString("surname");
                 fname = r.getString("firstname");
                 mname = r.getString("middlename");
                 gender = r.getString("gender");
                 sphone = r.getString("studentphone");
                 dept = r.getString("department");
                 level = r.getString("classlevel");
             }
         }
             catch (Exception e)
               {
                   System.out.println(e.getMessage()); 
                     }
         if(!regnum.equals("")){
        JOptionPane.showMessageDialog(null, "\t Name: " +sname+" "+fname+" "+mname+"\n Reg no: "+regnum+"\n Gender: "+gender+"\n Phone Number: "+sphone+"\n Department: "+dept+"\n Level: "+level, "INFORMATION", JOptionPane.PLAIN_MESSAGE );
         }
         else{
             Alert alert = new Alert(Alert.AlertType.INFORMATION);
             alert.setHeaderText(null);
             alert.setContentText("Student not found");
             alert.showAndWait();
         }
    }
}
