/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Records;

import Database.DatabaseHandler;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author Chioma Okeke
 */
public class RecordsUIController implements Initializable {

    @FXML
    private AnchorPane recordPane;
    @FXML
    private TableView<Records> recordTable;
    @FXML
    private TableColumn<Records, String> regnoCol;
    @FXML
    private TableColumn<Records, String> SurnameCol;
    @FXML
    private TableColumn<Records, String> FnameCol;
    @FXML
    private TableColumn<Records, String> MnameCol;
    @FXML
    private TableColumn<Records, String> dobCol;
    @FXML
    private TableColumn<Records, String> genderCol;
    @FXML
    private TableColumn<Records, String> phoneCol;
    @FXML
    private TableColumn<Records, String> guard1Col;
    @FXML
    private TableColumn<Records, String> guard2Col;
    @FXML
    private TableColumn<Records, String> modeCol;
    @FXML
    private TableColumn<Records, String> deptCol;
    @FXML
    private TableColumn<Records, String> levelCol;
    ObservableList<Records> data1 =FXCollections.observableArrayList();
    DatabaseHandler data = null;
    @FXML
    private Button back;
    private JFXTextField search;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        data = DatabaseHandler.getInstance();
        initCol();
        loadData();
    }    
    
    private void initCol(){
    regnoCol.setCellValueFactory(new PropertyValueFactory<>("regnumber"));
    SurnameCol.setCellValueFactory(new PropertyValueFactory<>("surname"));
    FnameCol.setCellValueFactory(new PropertyValueFactory<>("firstname"));
    MnameCol.setCellValueFactory(new PropertyValueFactory<>("middlename"));
    dobCol.setCellValueFactory(new PropertyValueFactory<>("DOB"));
    genderCol.setCellValueFactory(new PropertyValueFactory<>("gender"));
    phoneCol.setCellValueFactory(new PropertyValueFactory<>("studentphone"));
    guard1Col.setCellValueFactory(new PropertyValueFactory<>("guardian1phone"));
    guard2Col.setCellValueFactory(new PropertyValueFactory<>("guardian2phone"));
    modeCol.setCellValueFactory(new PropertyValueFactory<>("entrymode"));
    deptCol.setCellValueFactory(new PropertyValueFactory<>("department"));
    levelCol.setCellValueFactory(new PropertyValueFactory<>("classlevel"));
    }
    
     private void loadData() {
         String sql = "select regnumber,surname,firstname,middlename,DOB,gender,studentphone,guardian1phone,guardian2phone,entrymode,department,classlevel from student";
         ResultSet r = data.executeQuery(sql);
         try{
             while(r.next()){
             String regNo = r.getString("regnumber");
             String Sname = r.getString("surname");
             String Fname = r.getString("firstname");
             String Mname = r.getString("middlename");
             String date = r.getString("DOB");
             String Gender = r.getString("gender");
             String Sphone = r.getString("studentphone");
             String guardian1 = r.getString("guardian1phone");
             String guardian2 = r.getString("guardian2phone");
             String mode = r.getString("entrymode");
             String dept = r.getString("department");
             String level = r.getString("classlevel");
             
             data1.add(new Records(regNo,Sname,Fname,Mname,date,Gender,Sphone,guardian1,guardian2,mode,dept,level));
          
             }
         }
         catch(Exception e){
             System.out.println(e.getMessage());
         }
         recordTable.getItems().setAll(data1);
     }

    @FXML
    private void goBack(ActionEvent event) {
         try{
            Parent root= FXMLLoader.load(getClass().getResource("..\\Form\\FormUI.fxml"));
            Scene scene = new Scene(root);
            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setResizable(false);
            stage.setTitle("Students Record");
            stage.setScene(scene);
            stage.show();
        }
        catch(Exception e){
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText(null);
            alert.setContentText(e.getMessage());
            alert.showAndWait();}  
            try{
            Exit();
            }
            catch(Exception e){
                System.out.println(e.getMessage());
            }
    }
            
            void Exit() throws IOException {
            Stage stage = (Stage) recordPane.getScene().getWindow();
            stage.close();
    
    } 

   
    
         public static class Records{
         private SimpleStringProperty regnumber;
         private SimpleStringProperty surname;  
         private SimpleStringProperty firstname;  
         private SimpleStringProperty middlename;  
         private SimpleStringProperty DOB;  
         private SimpleStringProperty gender;  
         private SimpleStringProperty studentphone;  
         private SimpleStringProperty guardian1phone;  
         private SimpleStringProperty guardian2phone;  
         private SimpleStringProperty entrymode;  
         private SimpleStringProperty department;  
         private SimpleStringProperty classlevel; 

        public String getRegnumber() {
            return regnumber.get();
        }

        public String getSurname() {
            return surname.get();
        }

        public String getFirstname() {
            return firstname.get();
        }

        public String getMiddlename() {
            return middlename.get();
        }

        public String getDOB() {
            return DOB.get();
        }

        public String getGender() {
            return gender.get();
        }

        public String getStudentphone() {
            return studentphone.get();
        }

        public String getGuardian1phone() {
            return guardian1phone.get();
        }

        public String getGuardian2phone() {
            return guardian2phone.get();
        }

        public String getEntrymode() {
            return entrymode.get();
        }

        public String getDepartment() {
            return department.get();
        }

        public String getClasslevel() {
            return classlevel.get();
        }

        public Records(String regnumber, String surname, String firstname, String middlename, String DOB, String gender, String studentphone, String guardian1phone, String guardian2phone, String entrymode, String department, String classlevel) {
            this.regnumber = new SimpleStringProperty(regnumber);
            this.surname = new SimpleStringProperty(surname);
            this.firstname = new SimpleStringProperty(firstname);
            this.middlename =new SimpleStringProperty(middlename);
            this.DOB = new SimpleStringProperty(DOB);
            this.gender = new SimpleStringProperty(gender);
            this.studentphone = new SimpleStringProperty(studentphone);
            this.guardian1phone = new SimpleStringProperty(guardian1phone);
            this.guardian2phone = new SimpleStringProperty(guardian2phone);
            this.entrymode = new SimpleStringProperty(entrymode);
            this.department = new SimpleStringProperty(department);
            this.classlevel = new SimpleStringProperty(classlevel);
        }
         
         
         }
    
}
