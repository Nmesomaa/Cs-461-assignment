/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Register;

import Database.DatabaseHandler;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * FXML Controller class
 *
 * @author Chioma Okeke
 */
public class RegisterUIController implements Initializable {

    
    @FXML
    private JFXTextField regNo;
    @FXML
    private JFXTextField surname;
    @FXML
    private JFXTextField middlename;
    @FXML
    private JFXTextField firstname;
    @FXML
    private JFXTextField state;
    @FXML
    private DatePicker DOB;
    @FXML
    private RadioButton maleRB;
    @FXML
    private ToggleGroup gender;
    @FXML
    private RadioButton femaleRB;
    @FXML
    private JFXTextField guardian1;
    @FXML
    private JFXTextField studentsPhone;
    @FXML
    private JFXTextField guardian2;
    @FXML
    private JFXComboBox<String> entryMode;
    @FXML
    private TextArea address;
    @FXML
    private JFXTextField faculty;
    @FXML
    private JFXTextField level;
    @FXML
    private JFXTextField department;
    @FXML
    private JFXButton submit;
    @FXML
    private JFXButton back;
    @FXML
    private AnchorPane registerPane;
    ObservableList mode = FXCollections.observableArrayList("Mode of Entry","Regular","Diploma","Direct Entry","Pre-science","JUPEB");
    DatabaseHandler data = null;
    @FXML
    private JFXButton clear;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
     data = DatabaseHandler.getInstance();
     entryMode.setValue("Mode of Entry");
     entryMode.setItems(mode);
    }    

    @FXML
    private void submitForm(ActionEvent event) {
        String regno = regNo.getText();
        String Sname = surname.getText();
        String Fname = firstname.getText();
        String Mname = middlename.getText();
        String State = state.getText();
        String dob = DOB.getValue().toString();
        String Gender = "";
        String Studentphone = studentsPhone.getText();
        String Guardian1 = guardian1.getText();
        String Guardian2 = guardian2.getText();
        String mode = entryMode.getSelectionModel().getSelectedItem();
        String Address = address.getText();
        String Faculty = faculty.getText();
        String dept = department.getText();
        String Level = level.getText();
        
        if(maleRB.isSelected()){
        Gender = maleRB.getText();
        }
        else{
        Gender = femaleRB.getText();
        }
        System.out.println(regno+" "+Sname+" "+Fname+" "+Mname+" "+State+" "+dob+" "+Gender+" "+Studentphone+" "+Guardian1+" "+Guardian2+" "+mode+" "+Address+" "+Faculty+" "+dept+" "+Level);
        String sql = "insert into student " +
                     "values('"+regno+"','"+Sname+"','"+Fname+"','"+Mname+"','"+State+"','"+dob+"','"+Gender+"','"+Studentphone+"','"+Guardian1+"','"+Guardian2+"','"+mode+"','"+Address+"','"+Faculty+"','"+dept+"','"+Level+"')";
        System.out.println(sql);
        
        if(data.executeAction(sql)){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText(null);
        alert.setContentText("Student Created");
        alert.showAndWait();
        }
        else{
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setHeaderText(null);
        alert.setContentText("ERROR");
        alert.showAndWait();
        }
    }
    

    @FXML
    private void goBack(ActionEvent event) {
         try{
            Parent root= FXMLLoader.load(getClass().getResource("..\\Form\\FormUI.fxml"));
            Scene scene = new Scene(root);
            Stage stage = new Stage(StageStyle.DECORATED);
            stage.setResizable(false);
            stage.setTitle("Student Records");
            stage.setScene(scene);
            stage.show();
        }
        catch(Exception e){
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText(null);
            alert.setContentText(e.getMessage());
            alert.showAndWait();}  
            try{
            Exit();
            }
            catch(Exception e){
                System.out.println(e.getMessage());
            }
    }
     void Exit() throws IOException {
            Stage stage = (Stage) registerPane.getScene().getWindow();
            stage.close();
    
    } 

    @FXML
    private void clear(ActionEvent event) {
     regNo.setText("");
     surname.setText("");
     firstname.setText("");
     middlename.setText("");
     state.setText("");
     studentsPhone.setText("");
     guardian1.setText("");
     guardian2.setText("");
     address.setText("");
     faculty.setText("");
     department.setText("");
     level.setText("");
     DOB.setValue(null);
     entryMode.getSelectionModel().select(0);

    }
}
